using UnityEngine;

public static class ColorExtension
{
    public static bool IsVisibleAlpha(this Color color)
    {
        return color.a > 0;
    }
}