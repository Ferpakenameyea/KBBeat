using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class AnimationDirector : MonoBehaviour
{
    [Serializable]
    struct DirectorEvent
    {
        public float delayTime_seconds;
        public UnityEvent action;
    }
    [SerializeField] private List<DirectorEvent> events;

    private void Start()
    {
        foreach (var e in events)
        {
            StartCoroutine(DirectorCoroutine(e));
        }
    }

    private IEnumerator DirectorCoroutine(DirectorEvent directorEvent)
    {
        yield return new WaitForSeconds(directorEvent.delayTime_seconds);
        directorEvent.action.Invoke();
        yield break;
    }
}
