using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlinkSwitcher : MonoBehaviour
{
    [Serializable]
    struct BlinkFrame
    {
        public Material frameMaterial;
        public float frameTime_second;
    }
    [SerializeField] private List<BlinkFrame> frames;
    private MeshRenderer meshRenderer;
    private void Start()
    {
        meshRenderer = this.GetComponent<MeshRenderer>();
        StartCoroutine(BlinkCoroutine());
    }

    private IEnumerator BlinkCoroutine()
    {
        int index = 0;
        while (this.enabled == true)
        {
            this.meshRenderer.material = frames[index].frameMaterial;
            yield return new WaitForSeconds(frames[index].frameTime_second);
            index++;
            if (index == frames.Count) index = 0;
        }
    }
}
