using UnityEngine;

public class MethodsLibrary : MonoBehaviour
{
    [SerializeField] private GameObject firstCircle;
    [SerializeField] private GameObject secondCircle;
    [SerializeField] private GameObject thirdCircle;
    public void GenerateFirstCircle()
    {
        firstCircle.SetActive(true);
    }

    public void GenerateSecondCircle()
    {
        secondCircle.SetActive(true);
    }

    public void GenerateThirdCircle()
    {
        thirdCircle.SetActive(true);
    }
}
